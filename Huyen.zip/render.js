/* ============================
   AI WEEKEND TERMINAL
   PART 3A-1
============================ */

const terminal = document.getElementById("terminalOutput");
const input = document.getElementById("question");
const askBtn = document.getElementById("askBtn");

const popup = document.getElementById("popup");
const popupTitle = document.getElementById("popupTitle");
const popupBody = document.getElementById("popupBody");
const closePopup = document.getElementById("closePopup");

const beep = document.getElementById("beep");

const cpuValue = document.getElementById("cpuValue");
const coffeeValue = document.getElementById("coffeeValue");
const energyValue = document.getElementById("energyValue");
const weekendValue = document.getElementById("weekendValue");

const bootScreen = document.getElementById("bootScreen");
const bootText = document.getElementById("bootText");
const progressBar = document.getElementById("progressBar");
const main = document.getElementById("main");

const bootLines = [

"AI WEEKEND TERMINAL v5.0",

"Copyright © Weekend AI",

"",

"Loading AI Core...",

"Loading Hacker Engine...",

"Loading Coffee Module...",

"Loading Funny Database...",

"Loading Team Scanner...",

"Loading Matrix Background...",

"Connecting ChatGPT...",

"Checking Weekend Status...",

"System Ready."

];

let lineIndex = 0;
let progress = 0;

function boot(){

if(lineIndex < bootLines.length){

bootText.innerHTML += bootLines[lineIndex] + "\n";

lineIndex++;

progress += 100 / bootLines.length;

progressBar.style.width = progress + "%";

setTimeout(boot,350);

}else{

setTimeout(()=>{

bootScreen.style.display="none";

main.classList.remove("hidden");

startTerminal();

},800);

}

}

boot();

function startTerminal(){

printAI("🤖 AI ONLINE");

printAI("Gõ câu hỏi hoặc sử dụng các nút bên dưới.");

printAI("Chúc cả team cuối tuần thật vui ❤️");

}

function printUser(text){

terminal.innerHTML +=

`<div style="color:#ffd54f;margin:8px 0;">👤 ${text}</div>`;

scrollTerminal();

}

function printAI(text){

terminal.innerHTML +=

`<div style="margin:8px 0;">🤖 ${text}</div>`;

scrollTerminal();

}

function scrollTerminal(){

terminal.scrollTop=terminal.scrollHeight;

}

function popupMessage(title,msg){

popup.classList.remove("hidden");

popupTitle.innerText=title;

popupBody.innerText=msg;

}

closePopup.onclick=()=>{

popup.classList.add("hidden");

}

function random(min,max){

return Math.floor(Math.random()*(max-min+1))+min;

}

setInterval(()=>{

cpuValue.innerText=random(12,98)+"%";

coffeeValue.innerText=random(40,100)+"%";

energyValue.innerText=random(55,100)+"%";

},3000);

setInterval(()=>{

const d=new Date();

document.getElementById("clock").innerHTML=

d.toLocaleTimeString("vi-VN");

},1000);

/* ===== Matrix ===== */

const canvas=document.getElementById("matrix");

const ctx=canvas.getContext("2d");

canvas.width=window.innerWidth;

canvas.height=window.innerHeight;

const letters="01ABCDEFGHIJKLMNOPQRSTUVWXYZ#$%&@";

const fontSize=16;

const columns=Math.floor(canvas.width/fontSize);

const drops=[];

for(let i=0;i<columns;i++){

drops[i]=1;

}

function drawMatrix(){

ctx.fillStyle="rgba(0,0,0,.05)";

ctx.fillRect(0,0,canvas.width,canvas.height);

ctx.fillStyle="#00ff88";

ctx.font=fontSize+"px monospace";

for(let i=0;i<drops.length;i++){

const text=

letters[Math.floor(Math.random()*letters.length)];

ctx.fillText(text,i*fontSize,drops[i]*fontSize);

if(

drops[i]*fontSize>canvas.height

&&

Math.random()>0.975

){

drops[i]=0;

}

drops[i]++;

}

}

setInterval(drawMatrix,40);

window.onresize=()=>{

canvas.width=window.innerWidth;

canvas.height=window.innerHeight;

};

const aiAnswer=[

"Đã mô phỏng 1.024.576 kịch bản.",

"Hệ thống đánh giá bạn vẫn ổn 😄",

"Câu hỏi khá thú vị.",

"AI cần thêm cà phê để trả lời nhanh hơn ☕",

"Bug không đáng sợ bằng deadline 😂",

"Thứ Hai rồi cũng sẽ qua.",

"Đừng quên commit trước khi nghỉ nhé.",

"Bạn đang được AI đánh giá 99 điểm."

];/* ============================
   PART 3A-2
============================ */

function getAIReply(question){

let q=question.toLowerCase();

if(q.includes("lan")){

return "👑 Phân tích hoàn tất.\n\nTổ trưởng Lan đạt cấp độ Legendary Leader.\nSupport Team +100\nLeadership +100\nPatience +100 ❤️";

}

if(q.includes("bug")){

const arr=[

"🐞 Bug không tự sinh ra, chỉ chuyển sang máy đồng nghiệp.",

"🐞 Đã quét 999 bug nhưng chưa biết ở file nào 😂",

"🐞 Bình tĩnh... Restart rồi chạy lại thử."

];

return arr[random(0,arr.length-1)];

}

if(q.includes("deploy")){

const arr=[

"🚫 Khuyến nghị KHÔNG deploy chiều thứ 6.",

"✔ Có thể deploy... sau khi backup.",

"⚠ Production đang nhìn bạn."

];

return arr[random(0,arr.length-1)];

}

if(q.includes("cafe")||q.includes("coffee")){

return "☕ AI phát hiện bạn đang thiếu 1 ly cà phê.";

}

if(q.includes("lương")){

return "💰 AI đang tìm dữ liệu...\nKhông tìm thấy quyền truy cập 😂";

}

if(q.includes("thứ 2")||q.includes("monday")){

return "🚀 Chúc cả team thứ Hai đầy năng lượng, ít bug và nhiều niềm vui.";

}

if(q.includes("ot")){

return "😅 OT chỉ nên diễn ra khi có pizza miễn phí.";

}

return aiAnswer[random(0,aiAnswer.length-1)];

}

function askAI(){

const text=input.value.trim();

if(text==="") return;

beep.play();

printUser(text);

setTimeout(()=>{

printAI(getAIReply(text));

},500);

input.value="";

}

askBtn.onclick=askAI;

input.addEventListener("keypress",e=>{

if(e.key==="Enter"){

askAI();

}

});

/* ========= Popup ========= */

function showInfo(title,msg){

popupMessage(title,msg);

}

/* ========= Buttons ========= */

document.getElementById("energyBtn").onclick=()=>{

showInfo(

"⚡ Energy Scan",

"Động lực: "+random(80,100)+"%\n\nBug: "+random(0,20)+"%\n\nCà phê còn: "+random(40,100)+"%"

);

};

document.getElementById("coffeeBtn").onclick=()=>{

showInfo(

"☕ Coffee",

"AI khuyến nghị bổ sung ngay 1 ly cà phê.\nHiệu suất dự kiến tăng +300%."

);

};

document.getElementById("bugBtn").onclick=()=>{

const bug=[

"Không phát hiện bug 😎",

"Bug đang ẩn trong production 😂",

"Bug đã bỏ chạy."

];

showInfo("🐞 Bug Scanner",bug[random(0,bug.length-1)]);

};

document.getElementById("fortuneBtn").onclick=()=>{

const fortune=[

"✨ Hôm nay merge thành công.",

"🍀 Đồng nghiệp sẽ giúp bạn.",

"🚀 Thứ Hai sẽ cực kỳ thuận lợi.",

"⚠ Đừng deploy lúc 17:59."

];

showInfo(

"🎲 AI Fortune",

fortune[random(0,fortune.length-1)]

);

};

document.getElementById("jokeBtn").onclick=()=>{

const jokes=[

"😂 Git không sai. Bạn sai.",

"😂 Fix 1 bug. Xuất hiện 10 bug mới.",

"😂 Code chạy lần đầu? Mau chụp ảnh.",

"😂 Deadline luôn chạy nhanh hơn internet."

];

showInfo(

"😂 Random Joke",

jokes[random(0,jokes.length-1)]

);

};/* ============================
   PART 3A-3
============================ */

const scanBtn=document.getElementById("scanNameBtn");
const memberName=document.getElementById("memberName");
const table=document.getElementById("leaderTable");

const titles=[
"Code Master",
"Bug Hunter",
"Coffee Expert",
"Weekend Hero",
"Merge King",
"AI Friend",
"Debug Ninja",
"Terminal Pro"
];

scanBtn.onclick=()=>{

let name=memberName.value.trim();

if(name===""){

showInfo("AI","Vui lòng nhập tên.");

return;

}

beep.play();

if(name.toLowerCase()=="lan"){

popupMessage(

"👑 LEGENDARY LEADER",

`Tên: Lan

Leadership : 100%

Support Team : 100%

Patience : 100%

Motivation : 100%

🏆 AI đánh giá:

Cảm ơn tổ trưởng Lan đã luôn hỗ trợ và truyền động lực cho cả team.

Happy Weekend ❤️`

);

printAI("Leader Scan hoàn tất.");

return;

}

let work=random(70,100);
let luck=random(40,100);
let bug=random(0,100);

popupMessage(

"🔍 AI Scan",

`Tên: ${name}

Độ chăm chỉ: ${work}%

May mắn: ${luck}%

Tỉ lệ gặp Bug: ${bug}%

Danh hiệu:

${titles[random(0,titles.length-1)]}`

);

printAI("Đã phân tích thành công "+name);

};

const members=[

"Lan",

"Minh",

"Hùng",

"Linh",

"Phúc",

"Trang",

"Nam",

"Vy"

];

function loadTable(){

table.innerHTML="";

members.forEach(n=>{

let score=random(88,100);

let tr=document.createElement("tr");

tr.innerHTML=`

<td>${n}</td>

<td>${score}</td>

<td>${titles[random(0,titles.length-1)]}</td>

`;

table.appendChild(tr);

});

}

loadTable();

/* ===== Các nút còn lại ===== */

document.getElementById("leaderBtn").onclick=()=>{

popupMessage(

"👑 Leader",

"AI xác nhận:\n\nTổ trưởng Lan đang kích hoạt kỹ năng:\n\nBUFF TINH THẦN +999 ❤️"

);

};

document.getElementById("mondayBtn").onclick=()=>{

popupMessage(

"🚀 Monday Mode",

`AI dự đoán:

✔ Đi làm đúng giờ: ${random(70,99)}%

✔ Bug giảm: ${random(40,90)}%

✔ Năng lượng: ${random(80,100)}%

Chúc cả team một tuần mới thật nhiều niềm vui!`

);

};

document.getElementById("achievementBtn").onclick=()=>{

popupMessage(

"🏆 Achievement",

`Bạn đã mở khóa:

✔ Weekend Survivor

✔ Coffee Lover

✔ Bug Fighter

+500 EXP`

);

};

let secretClick=0;

document.getElementById("secretBtn").onclick=()=>{

secretClick++;

if(secretClick<5){

popupMessage(

"🔒 Secret",

"Nhấn thêm "+(5-secretClick)+" lần nữa..."

);

}else{

popupMessage(

"🎉 SECRET MODE",

`SYSTEM UNLOCKED

Cảm ơn cả team đã cùng nhau cố gắng suốt tuần.

Đặc biệt cảm ơn tổ trưởng Lan luôn hỗ trợ mọi người.

Chúc cuối tuần thật vui ❤️

Thứ Hai:

✔ Ít bug

✔ Nhiều tiếng cười

✔ Nhiều năng lượng

Happy Weekend!`

);

secretClick=0;

}

};

printAI("✔ AI Core Loaded");
printAI("✔ Matrix Engine Loaded");
printAI("✔ Funny Database Loaded");
printAI("✔ Weekend Mode Activated");/*==============================
      PART 3B-1
================================*/

const hackerReply = [

"🟢 Access Granted...",
"🔍 Đang truy cập AI Core...",
"⚡ Phân tích hoàn tất.",
"💻 Hacker Mode Activated.",
"🧠 AI vừa suy nghĩ xong.",
"📡 Đang kết nối vệ tinh cuối tuần...",
"☕ Cà phê đã nạp thành công.",
"🚀 Động lực tăng +999.",
"😂 AI xác nhận hôm nay nên cười nhiều hơn.",
"❤️ Chúc bạn cuối tuần thật vui."

];

const funnyReply=[

"Bug không tự mất. Nó chỉ sang máy người khác.",

"Code chạy lần đầu? Mau chụp ảnh.",

"Đừng deploy chiều thứ 6 😂",

"Git không sai. Bạn sai.",

"Ctrl + S là kỹ năng sinh tồn.",

"Deadline đang đến gần hơn bạn nghĩ.",

"Production đang theo dõi bạn 👀",

"AI khuyên nên uống thêm cà phê."

];

function randomText(arr){

return arr[Math.floor(Math.random()*arr.length)];

}

/*========== Quét nhân sự ==========*/

document.getElementById("scanBtn").onclick=()=>{

popupMessage(

"🔍 AI Scanner",

`Đang quét toàn bộ nhân sự...

██████░░░░ 45%

██████████ 100%

Hoàn tất.

AI phát hiện:

😀 Team đang rất vui.

☕ Thiếu khoảng ${random(3,15)} ly cà phê.

🐞 Bug còn ${random(2,20)} con.

❤️ Tinh thần đồng đội: 100%`

);

}

/*========== AI Surprise ==========*/

setInterval(()=>{

const arr=[

"🤖 AI: Hôm nay nhớ cười nhé 😄",

"☕ AI: Đã đến giờ uống nước.",

"🚀 AI: Thứ Hai không đáng sợ đâu.",

"😂 AI: Bug cũng cần cuối tuần."

];

printAI(randomText(arr));

},90000);

/*========== Typing Effect ==========*/

function typing(text){

let i=0;

let div=document.createElement("div");

terminal.appendChild(div);

let timer=setInterval(()=>{

div.innerHTML+=""+text.charAt(i);

i++;

scrollTerminal();

if(i>=text.length){

clearInterval(timer);

}

},20);

}/*==============================
          PART 3B-2
================================*/

/* ===== Lucky Machine ===== */

const luckyReward=[

"🎁 Thưởng thêm 1 ly trà sữa",

"☕ Miễn phí 1 ly cà phê",

"😂 Được quyền né 1 bug hôm nay",

"💻 AI review code miễn phí",

"🍀 May mắn +100",

"🚀 Hiệu suất +999",

"😎 Không bị gọi OT hôm nay",

"❤️ Đồng nghiệp sẽ giúp bạn fix bug"

];

function luckyMachine(){

let text="";

let count=0;

let timer=setInterval(()=>{

text="🎰 Đang quay...\n\n";

text+="██████████\n";

text+=randomText(luckyReward);

popupTitle.innerHTML="🎲 Lucky Machine";

popupBody.innerHTML=text;

popup.classList.remove("hidden");

count++;

if(count==12){

clearInterval(timer);

popupBody.innerHTML=

"🎉 KẾT QUẢ\n\n"+

randomText(luckyReward);

}

},120);

}

/* ===== Monday AI ===== */

const mondayQuotes=[

"💪 Chúc cả team khởi đầu tuần mới thật nhiều năng lượng.",

"🚀 Chúc mọi người code mượt, merge thành công.",

"❤️ Cảm ơn mọi người đã cố gắng suốt tuần trước.",

"☕ Nhớ uống đủ nước và cà phê nhé.",

"😂 Bug ít thôi để còn cười nhiều."

];

document.getElementById("mondayBtn").onclick=()=>{

popupMessage(

"🚀 Monday Mode",

randomText(mondayQuotes)

);

};

/* ===== Leader ===== */

document.getElementById("leaderBtn").onclick=()=>{

popupMessage(

"👑 AI Leader",

`Scanning...

██████████

Leader Found

Tên:

LAN

Leadership

██████████ 100%

Support Team

██████████ 100%

Patience

██████████ 100%

🏆 Achievement

LEGENDARY LEADER

❤️ AI cảm ơn tổ trưởng Lan
đã luôn hỗ trợ và truyền động lực cho cả team.`

);

};

/* ===== Achievement ===== */

const achievements=[

"🏆 Weekend Survivor",

"🏆 Bug Hunter",

"🏆 Coffee Master",

"🏆 Merge Hero",

"🏆 AI Friend",

"🏆 Terminal Hacker"

];

document.getElementById("achievementBtn").onclick=()=>{

popupMessage(

"🏆 Achievement",

randomText(achievements)+

"\n\n+500 EXP"

);

};

/* ===== Secret ===== */

let hackClick

document.getElementById("secretBtn").onclick=()=>{

hackClick++;

if(hackClick<5){}

popupMessage(

"🔒 Secret",

"Nhấn thêm "+(5-hackClick)+" lần nữa..."

);

}else

popupMessage(

"💚 HACKER MODE",

`ACCESS GRANTED

███████████0000

AI MESSAGE

Cảm ơn cả team
đã luôn hỗ trợ nhau.

Đặc biệt cảm ơn
tổ trưởng Lan
đã dẫn dắt team.

Happy Weekend ❤️`

);

hackClick=0;

}

};

/* ===== Lucky mỗi 2 phút ===== */

setInterval(()=>{

if(Math.random()>0.65){

typing(

"🤖 AI: "+randomText(hackerReply)

);

}

},120000);

/* ===== Nút Lucky ===== */

const luckyBtn=document.createElement("button");

luckyBtn.innerHTML="🎰 Lucky";

luckyBtn.className="actionBtn";

document.querySelector(".buttonGrid").appendChild(luckyBtn);

luckyBtn.onclick=luckyMachine;

typing("✔ Lucky Machine Loaded");
typing("✔ Achie