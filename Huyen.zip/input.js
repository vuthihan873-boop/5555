const train = document.getElementById("train");
const question = document.getElementById("question");
const no = document.getElementById("no");

window.onload = () => {

setTimeout(()=>{
train.style.left="50%";
train.style.transform="translateX(-50%)";
},300);

setTimeout(()=>{
question.style.display="block";
},8500);

};

// Nút chạy
function run(){

const w = window.innerWidth-140;
const h = window.innerHeight-120;

const x = Math.random()*w;
const y = Math.random()*h;

no.style.position="fixed";
no.style.left=x+"px";
no.style.top=y+"px";

const text=[
"Ơ kìa 😂",
"Bắt không được đâu 😝",
"Suy nghĩ lại đi 🥺",
"Đừng bấm tớ mà ❤️",
"Cho tớ một cơ hội nhé 🌹",
"Ấn nút bên trái đi 😆"
];

no.innerHTML=text[Math.floor(Math.random()*text.length)];

}

function yes(){

document.body.innerHTML=`

<div style="
height:100vh;
display:flex;
flex-direction:column;
justify-content:center;
align-items:center;
background:linear-gradient(#ff9ecf,#ffe6f2);
font-family:Arial;
text-align:center;
overflow:hidden;
">

<h1 style="color:#e91e63;font-size:38px;">
❤️ Cảm ơn Vy ❤️
</h1>

<p style="font-size:22px;width:85%;">
Cảm ơn cậu đã lên chuyến tàu mang tên <b>"Chúng Ta"</b>.<br><br>
Từ hôm nay hãy để tớ trở thành người luôn bên cạnh cậu nhé. 🌹
</p>

<div id="heartBox"></div>

</div>

`;

setInterval(()=>{

const heart=document.createElement("div");

heart.innerHTML="❤️";

heart.style.position="fixed";
heart.style.left=Math.random()*window.innerWidth+"px";
heart.style.top=window.innerHeight+"px";
heart.style.fontSize=(20+Math.random()*30)+"px";
heart.style.transition="4s linear";

document.body.appendChild(heart);

setTimeout(()=>{
heart.style.top="-100px";
heart.style.opacity="0";
},50);

setTimeout(()=>{
heart.remove();
},4000);

},200);

}// render.js

function firework() {

for(let i=0;i<80;i++){

let p=document.createElement("div");

p.innerHTML=["💖","✨","💕","🎉"][Math.floor(Math.random()*4)];

p.style.position="fixed";
p.style.left="50%";
p.style.top="50%";
p.style.fontSize=(18+Math.random()*18)+"px";
p.style.pointerEvents="none";

let angle=Math.random()*360;
let distance=100+Math.random()*250;

p.style.transition="1.5s ease-out";

document.body.appendChild(p);

setTimeout(()=>{

p.style.transform=`translate(${Math.cos(angle*Math.PI/180)*distance}px,
${Math.sin(angle*Math.PI/180)*distance}px)
rotate(${Math.random()*360}deg)`;

p.style.opacity="0";

},20);

setTimeout(()=>{
p.remove();
},1600);

}

}

// Gọi khi nhấn Đồng ý
const oldYes = window.yes;

window.yes = function(){

if(oldYes) oldYes();

setTimeout(()=>{

firework();

setInterval(firework,1800);

},500);

};