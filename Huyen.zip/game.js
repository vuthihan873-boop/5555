<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gửi em Trâm ❤️</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #ffe6e6, #ffb3b3);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            overflow: hidden;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 400px;
            position: relative;
        }
        h1 {
            color: #d63031;
            font-size: 28px;
            margin-bottom: 20px;
        }
        p {
            color: #4d4d4d;
            font-size: 18px;
            line-height: 1.5;
        }
        .btn-group {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 30px;
            height: 50px;
        }
        button {
            padding: 12px 30px;
            font-size: 18px;
            font-weight: bold;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        #btnYes {
            background-color: #2ecc71;
            color: white;
        }
        #btnNo {
            background-color: #e74c3c;
            color: white;
            position: absolute;
        }
    </style>
</head>
<body>

    <div class="container" id="gameBox">
        <h1 id="title">Trâm ơi! ❤️</h1>
        <p id="question">Trâm làm người yêu anh nhé? 🥰</p>
        
        <div class="btn-group">
            <button id="btnYes" onclick="sayYes()">Có 😍</button>
            <button id="btnNo" onmouseover="moveButton()">Không 😢</button>
        </div>
    </div>

    <script>
        const btnNo = document.getElementById('btnNo');
        const container = document.getElementById('gameBox');

        // Định vị trí ban đầu cho nút Không nằm bên phải nút Có
        btnNo.style.left = "210px";
        btnNo.style.bottom = "40px";

        // Hàm làm cho nút Không tự bỏ chạy khi di chuột vào
        function moveButton() {
            const containerRect = container.getBoundingClientRect();
            const btnRect = btnNo.getBoundingClientRect();

            // Tính toán khoảng cách tối đa để nút không chạy ra ngoài hộp thoại
            const maxX = containerRect.width - btnRect.width - 20;
            const maxY = containerRect.height - btnRect.height - 20;

            const randomX = Math.floor(Math.random() * maxX);
            const randomY = Math.floor(Math.random() * maxY);

            btnNo.style.left = randomX + 'px';
            btnNo.style.bottom = randomY + 'px';
        }

        // Hàm xử lý khi bấm nút Có
        function sayYes() {
            document.getElementById('title').innerHTML = "Hì hì biết ngay mà! 😘";
            document.getElementById('question').innerHTML = "Yêu em Trâm nhất trên đời! Tối nay anh qua đón đi chơi nhaaa! ❤️🎉";
            btnNo.style.display = 'none';
            document.getElementById('btnYes').style.transform = 'scale(1.2)';
            document.getElementById('btnYes').innerHTML = "Chốt luôn! 🚀";
        }
    </script>

</body>
</html>
