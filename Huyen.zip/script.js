//===============================
// CẢM ƠN EM | 06 • 07
// PHẦN 1
//===============================

//======================================
// Chỉnh ngày bắt đầu quen nhau
//======================================

// Đổi thành ngày của hai bạn
const startDate = new Date("18-05-2025 00:00:00");

//======================================
// Nội dung mở đầu
//======================================

const intro = `

Có những người...

đến để ở lại.

Cũng có những người...

chỉ xuất hiện

để trở thành

một ký ức đẹp.

`;

const typing = document.getElementById("typing");

let index = 0;

function typeIntro(){

if(index < intro.length){

typing.innerHTML += intro.charAt(index);

index++;

setTimeout(typeIntro,55);

}

}

typeIntro();

//======================================
// Đồng hồ đếm thời gian
//======================================

function updateLoveTimer(){

const now = new Date();

const diff = now - startDate;

const second = 1000;

const minute = second * 60;

const hour = minute * 60;

const day = hour * 24;

const year = day * 365;

const years = Math.floor(diff / year);

const days = Math.floor((diff % year) / day);

const hours = Math.floor((diff % day) / hour);

const minutes = Math.floor((diff % hour) / minute);

const seconds = Math.floor((diff % minute) / second);

document.getElementById("loveTimer").innerHTML =

`${years} năm<br>
${days} ngày<br>
${hours} giờ<br>
${minutes} phút<br>
${seconds} giây`;

}

setInterval(updateLoveTimer,1000);

updateLoveTimer();

//======================================
// Tạo sao trên trời
//======================================

const stars = document.getElementById("stars");

for(let i=0;i<180;i++){

const star=document.createElement("div");

star.className="star";

star.style.left=Math.random()*100+"vw";

star.style.top=Math.random()*100+"vh";

star.style.animationDuration=(1+Math.random()*3)+"s";

star.style.opacity=Math.random();

stars.appendChild(star);

}

//======================================
// Chữ trong bức thư
//======================================

const letter = `

Gửi cô gái sinh ngày 06 • 07.

Cảm ơn em...

vì đã từng bước vào cuộc đời anh.

Cảm ơn em...

vì đã mang đến cho anh

những ngày tháng thật đẹp.

Có lẽ...

chúng ta đã không đủ may mắn

để cùng nhau đi hết chặng đường.

Nhưng...

anh chưa từng hối hận

vì đã gặp em.

`;

let letterIndex=0;

const letterBox=document.getElementById("letterText");

function writeLetter(){

if(letterIndex < letter.length){

letterBox.innerHTML += letter.charAt(letterIndex);

letterIndex++;

setTimeout(writeLetter,45);

}

}

setTimeout(writeLetter,7000);//===============================
// PHẦN 4
// Hoa rơi - Tim bay - Sao băng - Nhạc
//===============================

//======================
// Hoa anh đào
//======================

const petals = document.getElementById("petals");

function createPetal(){

const petal = document.createElement("div");

petal.className = "petal";

petal.innerHTML = "🌸";

petal.style.left = Math.random()*100+"vw";

petal.style.fontSize = (16+Math.random()*18)+"px";

petal.style.animationDuration = (6+Math.random()*6)+"s";

petals.appendChild(petal);

setTimeout(()=>{
petal.remove();
},12000);

}

setInterval(createPetal,350);

//======================
// Trái tim
//======================

const hearts=document.getElementById("hearts");

function createHeart(){

const heart=document.createElement("div");

heart.className="heart";

heart.innerHTML="❤";

heart.style.left=Math.random()*100+"vw";

heart.style.fontSize=(12+Math.random()*25)+"px";

heart.style.animationDuration=(5+Math.random()*6)+"s";

hearts.appendChild(heart);

setTimeout(()=>{
heart.remove();
},12000);

}

setInterval(createHeart,900);

//======================
// Sao băng
//======================

function shootingStar(){

const star=document.createElement("div");

star.style.position="fixed";

star.style.width="2px";

star.style.height="120px";

star.style.background="linear-gradient(white,transparent)";

star.style.transform="rotate(45deg)";

star.style.left=Math.random()*80+"vw";

star.style.top="-120px";

star.style.zIndex="5";

document.body.appendChild(star);

let top=-120;

const move=setInterval(()=>{

top+=12;

star.style.top=top+"px";

if(top>window.innerHeight){

clearInterval(move);

star.remove();

}

},20);

}

setInterval(shootingStar,10000);

//======================
// Nhạc
//======================

const music=document.getElementById("music");

const musicBtn=document.getElementById("musicBtn");

let playing=false;

musicBtn.onclick=function(){

if(!playing){

music.play();

musicBtn.innerHTML="⏸";

playing=true;

}else{

music.pause();

musicBtn.innerHTML="🎵";

playing=false;

}

}//===============================
// PHẦN 5
// KẾT THÚC
//===============================

// Chờ 25 giây rồi hiện lời tạm biệt

setTimeout(() => {

    // Làm tối màn hình
    document.body.style.transition = "4s";
    document.body.style.background =
    "linear-gradient(#000,#020202,#000)";

    // Tạo lớp kết thúc
    const end = document.createElement("div");

    end.style.position = "fixed";
    end.style.top = "0";
    end.style.left = "0";
    end.style.width = "100%";
    end.style.height = "100%";
    end.style.display = "flex";
    end.style.flexDirection = "column";
    end.style.justifyContent = "center";
    end.style.alignItems = "center";
    end.style.background = "rgba(0,0,0,.82)";
    end.style.backdropFilter = "blur(6px)";
    end.style.zIndex = "99999";
    end.style.opacity = "0";
    end.style.transition = "3s";

    end.innerHTML = `

<h1 style="
font-size:55px;
color:#ffd6e7;
margin-bottom:30px;
text-shadow:0 0 20px pink;
">

Goodbye

</h1>

<h2 style="
font-size:70px;
color:#fff4b3;
letter-spacing:8px;
margin-bottom:40px;
">

06 • 07

</h2>

<p style="
width:85%;
max-width:750px;
font-size:24px;
line-height:45px;
text-align:center;
white-space:pre-line;
">

Có những cuộc gặp gỡ...

không phải để đi cùng nhau mãi mãi.

Mà để dạy chúng ta biết

cách yêu một người.

Cảm ơn em...

vì đã từng là

một phần thanh xuân của anh.

Anh sẽ không làm phiền em nữa.

Anh cũng không mong em quay lại.

Anh chỉ mong...

sau này...

dù ở bên ai...

em vẫn luôn hạnh phúc.

Tạm biệt.

❤️

</p>

<div style="
margin-top:70px;
font-size:18px;
opacity:.65;
">

Lê Bá Hưởng

</div>

`;

    document.body.appendChild(end);

    setTimeout(() => {

        end.style.opacity = "1";

    },300);

},25000);

//==============================
// Chữ "06 • 07" phát sáng
//==============================

setInterval(()=>{

const birthday=document.querySelector(".birthday");

birthday.style.transform="scale(1.05)";

setTimeout(()=>{

birthday.style.transform="scale(1)";

},600);

},2500);

//==============================
// Hiệu ứng cuộn mượt
//==============================

document.documentElement.style.scrollBehavior="smooth";//==============================
// PHẦN 6 - KẾT THÚC
//==============================

// Sau 40 giây sẽ xuất hiện ngôi sao cuối cùng

setTimeout(() => {

    // Xóa hoa
    document.getElementById("petals").innerHTML = "";

    // Xóa tim
    document.getElementById("hearts").innerHTML = "";

    // Tạo ngôi sao cuối

    const lastStar = document.createElement("div");

    lastStar.innerHTML = "⭐";

    lastStar.style.position = "fixed";
    lastStar.style.left = "50%";
    lastStar.style.top = "42%";
    lastStar.style.transform = "translate(-50%,-50%)";
    lastStar.style.fontSize = "70px";
    lastStar.style.zIndex = "999999";
    lastStar.style.animation = "glow 2s infinite alternate";

    document.body.appendChild(lastStar);

    // Tạo lời nhắn

    const goodbye = document.createElement("div");

    goodbye.style.position = "fixed";
    goodbye.style.left = "50%";
    goodbye.style.top = "58%";
    goodbye.style.transform = "translateX(-50%)";
    goodbye.style.width = "90%";
    goodbye.style.maxWidth = "700px";
    goodbye.style.textAlign = "center";
    goodbye.style.color = "white";
    goodbye.style.lineHeight = "42px";
    goodbye.style.fontSize = "23px";
    goodbye.style.zIndex = "999999";
    goodbye.style.whiteSpace = "pre-line";

    goodbye.innerHTML = `

Nếu sau này...

vô tình gặp lại nhau.

Anh hy vọng...

chúng ta sẽ mỉm cười.

Không trách móc.

Không oán giận.

Chỉ đơn giản là...

"Cảm ơn vì đã từng xuất hiện."

————————————

Gửi cô gái sinh ngày

06 • 07

Chúc em...

một đời bình an.

một đời hạnh phúc.

❤️

`;

    document.body.appendChild(goodbye);

},40000);

//==============================
// Kết thúc sau 60 giây
//==============================

setTimeout(()=>{

document.body.innerHTML=`

<div style="

height:100vh;

display:flex;

justify-content:center;

align-items:center;

flex-direction:column;

background:black;

color:white;

font-family:Quicksand;

">

<h1 style="font-size:60px;color:#ffd6e7;">

Goodbye

</h1>

<h2 style="margin-top:20px;font-size:55px;">

06 • 07

</h2>

<p style="margin-top:40px;font-size:22px;opacity:.7;">

Cảm ơn em vì đã từng là

một phần thanh xuân của anh.

</p>

<p style="margin-top:80px;opacity:.45;">

Lê Bá Hưởng

</p>

</div>

`;

},60000);